package guiprac;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class CustomerDashboard extends JFrame {
    private int userId;

    public CustomerDashboard(int userId) {
        this.userId = userId;
        setTitle("Customer Dashboard");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome, Customer!", SwingConstants.CENTER);

        DefaultListModel<String> productList = new DefaultListModel<>();
        JList<String> productJList = new JList<>(productList);

        // Populate product list from database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
            String sql = "SELECT * FROM Products";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                productList.addElement(rs.getInt("id") + ": " + rs.getString("name") + " - $" + rs.getDouble("price"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage());
        }

        JTextField quantityField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField dateField = new JTextField("YYYY-MM-DD");
        JButton orderButton = new JButton("Place Order");
        JButton logoutButton = new JButton("Logout");

        JPanel formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.add(new JLabel("Select Product:"));
        formPanel.add(new JScrollPane(productJList));
        formPanel.add(new JLabel("Quantity (kg):"));
        formPanel.add(quantityField);
        formPanel.add(new JLabel("Delivery Address:"));
        formPanel.add(addressField);
        formPanel.add(new JLabel("Delivery Date:"));
        formPanel.add(dateField);
        formPanel.add(orderButton);
        formPanel.add(logoutButton);

        panel.add(welcomeLabel, BorderLayout.NORTH);
        panel.add(formPanel, BorderLayout.CENTER);

        add(panel);

        orderButton.addActionListener(e -> {
            String selectedProduct = productJList.getSelectedValue();
            if (selectedProduct == null) {
                JOptionPane.showMessageDialog(this, "Please select a product.");
                return;
            }

            int productId = Integer.parseInt(selectedProduct.split(":")[0]);
            int quantity = Integer.parseInt(quantityField.getText());
            String address = addressField.getText();
            String date = dateField.getText();

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
                String sql = "INSERT INTO Deliveries (customer_id, product_id, quantity, delivery_date, delivery_address) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, userId);
                stmt.setInt(2, productId);
                stmt.setInt(3, quantity);
                stmt.setString(4, date);
                stmt.setString(5, address);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Order placed successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        logoutButton.addActionListener(e -> {
            dispose(); // Close the dashboard
            new LoginPage().setVisible(true); // Go back to login
        });
    }
}


