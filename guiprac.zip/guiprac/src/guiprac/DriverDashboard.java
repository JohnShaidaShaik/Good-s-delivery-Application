package guiprac;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class DriverDashboard extends JFrame {
    private int userId;

    public DriverDashboard(int userId) {
        this.userId = userId;
        setTitle("Driver Dashboard");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome, Driver!", SwingConstants.CENTER);

        DefaultListModel<String> missionList = new DefaultListModel<>();
        JList<String> missionJList = new JList<>(missionList);

        // Load assigned missions
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
            String sql = "SELECT id, route, mission_date, status FROM Missions WHERE driver_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                missionList.addElement("Mission ID: " + rs.getInt("id") + ", Route: " + rs.getString("route") +
                        ", Date: " + rs.getDate("mission_date") + ", Status: " + rs.getString("status"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading missions: " + ex.getMessage());
        }

        JButton completeMissionButton = new JButton("Mark as Completed");
        JButton logoutButton = new JButton("Logout");

        JPanel actionPanel = new JPanel(new GridLayout(2, 1));
        actionPanel.add(completeMissionButton);
        actionPanel.add(logoutButton);

        panel.add(welcomeLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(missionJList), BorderLayout.CENTER);
        panel.add(actionPanel, BorderLayout.SOUTH);

        add(panel);

        // Complete Mission Button Action
        completeMissionButton.addActionListener(e -> {
            String selectedMission = missionJList.getSelectedValue();
            if (selectedMission == null) {
                JOptionPane.showMessageDialog(this, "Please select a mission to complete.");
                return;
            }

            int missionId = Integer.parseInt(selectedMission.split(":")[1].split(",")[0].trim());

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
                String sql = "UPDATE Missions SET status = 'completed' WHERE id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, missionId);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Mission marked as completed!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating mission status: " + ex.getMessage());
            }
        });

        // Logout Button Action
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });
    }
}

