package guiprac;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class RegistrationPage extends JFrame {
    public RegistrationPage() {
        setTitle("User Registration");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(9, 2, 10, 10));
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel phoneLabel = new JLabel("Phone Number:");
        JTextField phoneField = new JTextField();
        JLabel roleLabel = new JLabel("Role:");
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"customer", "scheduler", "driver"});
        JLabel truckRegLabel = new JLabel("Truck Registration Number:");
        JTextField truckRegField = new JTextField();
        JLabel truckCapacityLabel = new JLabel("Truck Capacity (Kg):");
        JTextField truckCapacityField = new JTextField();
        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back to Login");

        // Add components to panel
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(roleLabel);
        panel.add(roleComboBox);
        panel.add(truckRegLabel);
        panel.add(truckRegField);
        panel.add(truckCapacityLabel);
        panel.add(truckCapacityField);
        panel.add(registerButton);
        panel.add(backButton);

        add(panel);

        // Hide truck fields by default
        truckRegLabel.setVisible(false);
        truckRegField.setVisible(false);
        truckCapacityLabel.setVisible(false);
        truckCapacityField.setVisible(false);

        // Show/hide truck fields based on role selection
        roleComboBox.addActionListener(e -> {
            String selectedRole = (String) roleComboBox.getSelectedItem();
            boolean isDriver = selectedRole.equals("driver");
            truckRegLabel.setVisible(isDriver);
            truckRegField.setVisible(isDriver);
            truckCapacityLabel.setVisible(isDriver);
            truckCapacityField.setVisible(isDriver);
        });

        // Register button action
        registerButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String phoneNumber = phoneField.getText().trim();
            String role = (String) roleComboBox.getSelectedItem();
            String truckRegNumber = truckRegField.getText().trim();
            String truckCapacityText = truckCapacityField.getText().trim();

            if (email.isEmpty() || password.isEmpty() || phoneNumber.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
                return;
            }

            if (role.equals("driver") && (truckRegNumber.isEmpty() || truckCapacityText.isEmpty())) {
                JOptionPane.showMessageDialog(this, "Please fill in truck details for drivers.");
                return;
            }

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
                String sql = "INSERT INTO Users (email, password, phone_number, role, truck_registration_number, truck_capacity) " +
                             "VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, email);
                stmt.setString(2, password);
                stmt.setString(3, phoneNumber);
                stmt.setString(4, role);

                if (role.equals("driver")) {
                    stmt.setString(5, truckRegNumber);
                    stmt.setInt(6, Integer.parseInt(truckCapacityText));
                } else {
                    stmt.setNull(5, java.sql.Types.VARCHAR);
                    stmt.setNull(6, java.sql.Types.INTEGER);
                }

                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Registration successful! Please log in.");
                dispose();
                new LoginPage().setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        // Back to Login button action
        backButton.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegistrationPage().setVisible(true));
    }
}
