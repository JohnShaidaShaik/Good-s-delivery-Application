package guiprac;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileOutputStream; // Import for FileOutputStream
import java.sql.*;
import org.apache.poi.xwpf.usermodel.*;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import java.io.FileOutputStream;
import java.io.IOException;

class SchedulerDashboard extends JFrame {
    public SchedulerDashboard() {
        setTitle("Scheduler Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome, Scheduler!", SwingConstants.CENTER);

        DefaultListModel<String> deliveryList = new DefaultListModel<>();
        JList<String> deliveryJList = new JList<>(deliveryList);

        // Load deliveries from database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
            String sql = "SELECT d.id, p.name, d.quantity, d.delivery_date, d.delivery_address " +
                         "FROM Deliveries d JOIN Products p ON d.product_id = p.id ORDER BY d.delivery_date";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                deliveryList.addElement("Delivery ID: " + rs.getInt("id") + ", Product: " + rs.getString("name") +
                        ", Quantity: " + rs.getInt("quantity") + "kg, Date: " + rs.getDate("delivery_date") +
                        ", Address: " + rs.getString("delivery_address"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading deliveries: " + ex.getMessage());
        }

        JComboBox<String> driverDropdown = new JComboBox<>();
        JTextField selectedDateField = new JTextField("YYYY-MM-DD");
        JButton assignButton = new JButton("Assign to Driver");
        JButton generateDocButton = new JButton("Generate Assignments Document");
        JButton logoutButton = new JButton("Logout");

        // Populate driver dropdown
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
            String sql = "SELECT id, email FROM Users WHERE role = 'driver'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                driverDropdown.addItem("Driver ID: " + rs.getInt("id") + " (" + rs.getString("email") + ")");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading drivers: " + ex.getMessage());
        }

        JPanel actionPanel = new JPanel(new GridLayout(6, 1));
        actionPanel.add(new JLabel("Select Delivery:"));
        actionPanel.add(new JScrollPane(deliveryJList));
        actionPanel.add(new JLabel("Select Driver:"));
        actionPanel.add(driverDropdown);
        actionPanel.add(assignButton);
        actionPanel.add(generateDocButton);
        actionPanel.add(new JLabel("Document Date:"));
        actionPanel.add(selectedDateField);
        actionPanel.add(logoutButton);

        panel.add(welcomeLabel, BorderLayout.NORTH);
        panel.add(actionPanel, BorderLayout.CENTER);

        add(panel);

        // Assign Button Action
        assignButton.addActionListener(e -> {
            String selectedDelivery = deliveryJList.getSelectedValue();
            String selectedDriver = (String) driverDropdown.getSelectedItem();

            if (selectedDelivery == null || selectedDriver == null) {
                JOptionPane.showMessageDialog(this, "Please select both a delivery and a driver.");
                return;
            }

            // Validate and extract delivery ID from selected delivery string
            int deliveryId = -1;
            try {
                deliveryId = Integer.parseInt(selectedDelivery.split(":")[1].split(",")[0].trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Delivery ID. Please select a valid delivery.");
                return;
            }

            // Validate and extract driver ID from selected driver string
            int driverId = -1;
            try {
                // Split on " (" to extract driver ID portion before the parentheses
                String[] driverParts = selectedDriver.split(" \\(");
                if (driverParts.length > 0) {
                    String driverIdPart = driverParts[0].split(":")[1].trim();  // Extract ID after "Driver ID:"
                    driverId = Integer.parseInt(driverIdPart);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Driver ID. Please select a valid driver.");
                return;
            }

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
                String sql = "INSERT INTO Missions (driver_id, route, mission_date) VALUES (?, ?, CURDATE())";
                PreparedStatement stmt = conn.prepareStatement(sql);

                stmt.setInt(1, driverId);
                stmt.setString(2, "Delivery ID: " + deliveryId);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Delivery assigned successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error assigning delivery: " + ex.getMessage());
            }
        });

        // Generate Document Button Action
        generateDocButton.addActionListener(e -> {
            String selectedDate = selectedDateField.getText();

            // Validate date input
            if (!selectedDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid date in YYYY-MM-DD format.");
                return;
            }

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics", "root", "")) {
                String sql = "SELECT m.id, u.email, m.route FROM Missions m JOIN Users u ON m.driver_id = u.id WHERE mission_date = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, selectedDate);
                ResultSet rs = stmt.executeQuery();

                XWPFDocument document = new XWPFDocument();

                XWPFParagraph title = document.createParagraph();
                XWPFRun run = title.createRun();
                run.setText("Assignments for " + selectedDate);
                run.setBold(true);
                run.setFontSize(16);

                while (rs.next()) {
                    XWPFParagraph para = document.createParagraph();
                    XWPFRun runBody = para.createRun();
                    runBody.setText("Driver: " + rs.getString("email") + ", Mission: " + rs.getString("route"));
                }

                // Save document
                try (FileOutputStream fos = new FileOutputStream("Assignments_" + selectedDate + ".docx")) {
                    document.write(fos);
                }

                JOptionPane.showMessageDialog(this, "Document generated successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error generating document: " + ex.getMessage());
            }
        });

        // Logout Button Action
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });
    }
}
